const settings = {
  packname: 'Queen-Grace-MD',
  author: '‎',
  botName: "𝐐𝐔𝐄𝐄𝐍 𝐆𝐑𝐀𝐂𝐄-𝐌𝐃",
  botOwner: 'PROGRESS TECH', // Your name
  ownerNumber: '237682432296', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.9",
  updateZipUrl: "hhttps://github.com/danielheart12332-dev/Queen-Grace-MD/archive/refs/heads/main.zip'",
};

module.exports = settings;
